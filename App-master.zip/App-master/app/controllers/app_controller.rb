class AppController < ApplicationController
  def index
  end
end
